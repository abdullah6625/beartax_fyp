 'use strict'
  var utility= require('./utility');
  module.exports=utility;