module.exports = {
    servingFromDB :"beatax",
    supportedDatabases :{
        mongodb : "mongodb",
        nedb : "nedb",
    }
}