'use strict'
 var constants = require('./constants');
 module.exports= constants;