var users = require('./user_model');
var exchanges =require('./exchanges_model');
var transactions=require('./transactions_model');
module.exports={
    exchanges:exchanges,
    users:users,
    transactions:transactions

}