'use strict'
var   mongo= require('./mongodb');

module.exports=mongo;