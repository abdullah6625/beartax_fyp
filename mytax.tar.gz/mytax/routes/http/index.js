  'use strict'
var routes = require('./routes');
var validations = require('../validations/'); 
module.exports = routes;
